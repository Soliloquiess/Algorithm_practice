package SWEA;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.Buffer;
import java.util.StringTokenizer;

public class SWEA_2027_�밢��_����ϱ� {
//
//	public static void main(String[] args) {
//		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
//		StringTokenizer st;
//
//	}
//
//}
	public static void main(String args[]) {
	        System.out.println("#++++");
	        System.out.println("+#+++");
	        System.out.println("++#++");
	        System.out.println("+++#+");
	        System.out.println("++++#");
	    
	}
}